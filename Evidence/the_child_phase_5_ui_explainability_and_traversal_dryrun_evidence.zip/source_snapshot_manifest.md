# Phase 5 Source Snapshot Manifest

Generated: 2026-06-28T19:46:10.6281407+05:30

| SHA-256 | Relative path |
|---|---|
| `04b3ddc2197af2bdd21db4aa01377a8c6c3bb14c40a6007441d32911241d5985` | `.agents/skills/auditing-rules-of-life/agents/openai.yaml` |
| `f55e3aa42948bf977230b1d5e7d9dacdef390b1d9c4f3a75d0596c02b3fede15` | `.agents/skills/auditing-rules-of-life/references/browser-verification.md` |
| `c9735337362123dedb50245fc20f5fc0019ec665f6e8b55c68ede5a16c529209` | `.agents/skills/auditing-rules-of-life/references/rules-of-life-v1.csv` |
| `5a42610648ca20f45604a14fc5ea8298e1227f6bc0c777fd3148ff4406b3cc9b` | `.agents/skills/auditing-rules-of-life/references/rules-of-life-v2.csv` |
| `10c461d546b02409a3d05fec34357bc8301b65787a7302b8e2110e77fc19912d` | `.agents/skills/auditing-rules-of-life/scripts/audit-harness.ps1` |
| `48ebddba7d9a772ff653fdce55b993edb0f1de0187267ef35492e84b5b5b24c6` | `.agents/skills/auditing-rules-of-life/scripts/self-test.ps1` |
| `8eb0659b3bdde2f5b76d6bfb33edf3221dec6d31d944872ea7c887b093a58fd6` | `.agents/skills/auditing-rules-of-life/SKILL.md` |
| `b6d12c728de0aac8b0bc6239e53aa8088c1431bcb4f9a3d61e5e8a2df1c7c400` | `.env.example` |
| `db691f14fcf678985362a42c6aedb581e42cd6bb99962ce1b44aea460fb2a4df` | `.gitignore` |
| `b5a1b4bb457eded1c68ffa133748651b475b26f62f55a4e4b8b9495e18e045d7` | `index.html` |
| `e68c5edc18b1c7c6be8947b2654c93a19f99e8f7fdae0b176e39ad1468790c54` | `metadata.json` |
| `ef415847541f7ec9b90d884760f5b36fcca072af94236addaee618b1f1165817` | `package-lock.json` |
| `7d0febe3dade6a4ce5e230ebbb8ccc5749894085d1df312eb64e325701a707be` | `package.json` |
| `7f30293c6d8e5e9435d9a6e45aa10583c1fb46a25565643734fbcb5e33ae399f` | `README.md` |
| `cf001df521cf793a0f06e54a745ab937fa12afb727ae540b9f7352539ec985e8` | `src/App.tsx` |
| `72d37bbdbb71354446ab2ebad599ea9a80a7740dd960dec9caea91ff7d44a97f` | `src/components/BrainLog.tsx` |
| `c40b1c0afc29807fea7fb3f4c39c01c3dc2c5b53d7a0a70900de67c5f722d366` | `src/components/ChildStatus.tsx` |
| `0e098e1d0d93c0291bf9b79f71e872c40e438bc77a7297b94ca12f51496f3e57` | `src/components/CurrentRunSummary.tsx` |
| `4658eefc088b360f8aac307194e678cd22e9bfb2809dc400a4f928a9a2b4ff66` | `src/components/DryRunPanel.tsx` |
| `218c0520e17521adbbc088c240c432c392fc5d68d1e9cebbbc906b0764fc34a7` | `src/components/LastRunReportPanel.tsx` |
| `a35f1d74d9adead2e08c56ffc091421bf4d09fb9546d3ce5744425a78be9a627` | `src/components/MemoryPanels.tsx` |
| `7022a273ad38df639c3217d0c6c302b1d5bb6f822f9af8111708d1944b2144b8` | `src/components/MotherRulesPanel.tsx` |
| `77b4ad99c65f7e90d2ad69c2bad54161e404a093575bdd8c80f4939790b97c90` | `src/components/MotherStatus.tsx` |
| `b68e5dfab7d208015150a77203b19a8baa1a9e0ce13567e9dc39fccb0b5410f6` | `src/components/NeedControl.tsx` |
| `fd787ffe4796e682499881159256ffbe07fb77f3364ed8f9d3967d146b540be7` | `src/components/SpeechStream.tsx` |
| `40f4e2c8d7f59361c5cb7683c1cd622ca7b49c3d680dba3dfc89363c2e976a96` | `src/components/TopBar.tsx` |
| `d6e063135440771a8e55ef3dc752ccca3028edfb698268269d6549c4795092bb` | `src/components/TraversalPanel.tsx` |
| `03860de2a0130a69c16e09c617109bbff3dd53de9c975c06a562fce36a88cef6` | `src/constants.ts` |
| `65a1555fe592ba60ef5247f519c3fb9e0162af4906e0ebd5b65ca424cfc24ac2` | `src/context/SimulationContext.tsx` |
| `acc754b4c7aac24bf38955024d34b7da46692dc6051b82f0bdf4596bacd6de5e` | `src/index.css` |
| `5580d48b0fec68698a113d45a640b88d479dc35eb1f4b87c51f67c6cc81cee9b` | `src/main.tsx` |
| `276d838064ca8762cfe22b167006132ecd2b135eff1c81f0fbb1655aff831ddf` | `src/simulation/clock.test.ts` |
| `ed5b542fcf30688b3aee9ebb48fd6c6d46c19abce1956f115427655d0998532f` | `src/simulation/clock.ts` |
| `4056d24614f7e2039d71048efeeed4948697c7f409a9c913e5bbaba3038e81fa` | `src/simulation/engine.test.ts` |
| `853affeb58c7102a178e593b298b090320ed2da2b3cb9105ea7967b407fa5823` | `src/simulation/engine.ts` |
| `3f7a7ab3f5aad435db200dde6d5b92e9c0b15cfcaf729298c50a984c4be97e18` | `src/simulation/explainability.test.ts` |
| `9bb7f24ce12f1b25fab174c5888b77d905902adbc8630aec1922f222726da3cd` | `src/simulation/explainability.ts` |
| `e80ef0418ffc0480c8f9264e4be010238447ccd5e7d682c77d5b047e045c4c55` | `src/simulation/persistence.test.ts` |
| `37c50ae1844bacb19c182e3250c9d1e37a2dbc28a698d63ad34ea03e7ddde6df` | `src/simulation/persistence.ts` |
| `02174b8331d7f69a9a105af1758b2e647e3fcac1c1450b31154753ea110405c7` | `src/types.ts` |
| `bfd800792dc0a53dac461ac15117862e9d0a664f0773c813e9e897f9bb2e13c1` | `tsconfig.json` |
| `c7b7cc4b3a6b6a08f0a4fb916bb4d4e41804d5767611bce43d4c1ad53a198192` | `vite.config.ts` |
