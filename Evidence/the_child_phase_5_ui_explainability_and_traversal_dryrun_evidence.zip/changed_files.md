# Changed Files

## Added

- `src/components/CurrentRunSummary.tsx`
- `src/components/DryRunPanel.tsx`
- `src/components/LastRunReportPanel.tsx`
- `src/simulation/clock.ts`
- `src/simulation/clock.test.ts`
- `src/simulation/explainability.ts`
- `src/simulation/explainability.test.ts`

## Modified application/tests

- `src/App.tsx`
- `src/components/BrainLog.tsx`
- `src/components/MemoryPanels.tsx`
- `src/components/MotherRulesPanel.tsx`
- `src/components/NeedControl.tsx`
- `src/components/SpeechStream.tsx`
- `src/components/TraversalPanel.tsx`
- `src/context/SimulationContext.tsx`
- `src/index.css`
- `src/simulation/engine.ts`
- `src/simulation/engine.test.ts`
- `src/simulation/persistence.ts`
- `src/simulation/persistence.test.ts`
- `src/types.ts`

## Modified audit skill

- `.agents/skills/auditing-rules-of-life/SKILL.md`
- `.agents/skills/auditing-rules-of-life/references/browser-verification.md`
- `.agents/skills/auditing-rules-of-life/scripts/self-test.ps1`

Package/config files, Base words, default rules, V2 key, and canonical rulesets were unchanged.
