# Phase 5 Diff Summary

| Before | After |
|---|---|
| Live state split across panels | Dominant Current Run Summary with reason |
| Horizontal rail hid later sources | Pinned source plus complete vertical timeline |
| Speech showed words only | Source/current word/index/remaining/no-repeat metadata |
| Rule/memory cards always dense | Compact expandable summaries |
| Previous run inferred from log | Persisted Last Run Report |
| One long event stream | Seven filters; structural Traversal view |
| No-rule warning only stated absence | Exhaustion consequence and expected rule |
| No preview | Read-only actual-engine Dry Run |
| “Depth-first” label | Accurate depth-major label |
| Reducer dispatched every frame | Elapsed-time-equivalent 50 ms external clock |

No brain-rule redesign occurred.
