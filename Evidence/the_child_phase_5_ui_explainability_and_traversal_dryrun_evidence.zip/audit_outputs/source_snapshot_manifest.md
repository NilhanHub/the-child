# Source Snapshot Manifest

Ruleset: v2

Files: 35

- `.env.example`
- `.gitignore`
- `index.html`
- `metadata.json`
- `package-lock.json`
- `package.json`
- `README.md`
- `tsconfig.json`
- `vite.config.ts`
- `src/App.tsx`
- `src/constants.ts`
- `src/index.css`
- `src/main.tsx`
- `src/types.ts`
- `src/components/BrainLog.tsx`
- `src/components/ChildStatus.tsx`
- `src/components/CurrentRunSummary.tsx`
- `src/components/DryRunPanel.tsx`
- `src/components/LastRunReportPanel.tsx`
- `src/components/MemoryPanels.tsx`
- `src/components/MotherRulesPanel.tsx`
- `src/components/MotherStatus.tsx`
- `src/components/NeedControl.tsx`
- `src/components/SpeechStream.tsx`
- `src/components/TopBar.tsx`
- `src/components/TraversalPanel.tsx`
- `src/context/SimulationContext.tsx`
- `src/simulation/clock.test.ts`
- `src/simulation/clock.ts`
- `src/simulation/engine.test.ts`
- `src/simulation/engine.ts`
- `src/simulation/explainability.test.ts`
- `src/simulation/explainability.ts`
- `src/simulation/persistence.test.ts`
- `src/simulation/persistence.ts`
