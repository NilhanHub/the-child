# Browser Observations

- Browser checked: YES — in-app Browser against the audit-owned Vite server on port 4175.
- Storage writes blocked: YES — the isolated app mounted with storage reads returning null and writes intercepted.
- Storage unchanged: YES — raw localStorage and sessionStorage were byte-identical before and after; 301 writes were blocked.
- Console health: PASS — zero warnings and zero errors in the final clean run, including a zero-gap seven-source traversal.
- Desktop: PASS at the default 1280×720 viewport.
- Mobile: PASS at 390×844; document width was 375px inside a 390px viewport, with Current Run Summary visually first.
- Test data: three Needs (milk, water, food) were given two isolated successful generations each. Their test-only Mother delays were set to 0 seconds.
- Controlled timing: `Math.random` was temporarily set to zero inside the disposable tab to exercise the valid zero-gap boundary deterministically.
- Factory Reset: not used.

## Scenarios

- Known Need: food showed own-memory only, pinned current source, Base blocked, no-repeat active, and a retained Last Run Report.
- New Need: juice displayed seven ordered sources; the pinned current-source card remained visible while steps 6 and 7 were exposed in the vertical timeline.
- Exhaustion: juice traversed borrowed active memories, skipped globally-used active/archive sources, reached Base, spoke 70 unique words, and waited at source exhaustion.
- No rule: the warning explained likely unsatisfied exhaustion and the Create matching rule action successfully created `juice → trigger juice → give juice`.
- Dry run known: food showed own active memory only with Base/archive blocked and trigger present.
- Dry run new: juice showed active depth 0, archived depth 1, and Base final. It correctly said a found diagnostic word would not schedule Mother without a matching rule.
- Dry run missing: `not-anywhere` produced the explicit exhaust-all-and-wait outcome.
- Mother search: milk and water filtered correctly; an unknown query showed the friendly no-results state; clear restored all rules.
- Event log: Traversal filter excluded per-word selection noise, retained structural transition events, preserved Newest first, and Jump to latest worked.
- Compact disclosures: Mother rule editing and Need memory/history expansion remained usable while collapsed summaries stayed scannable.

## Screenshots

Eleven PNG files cover Current Run Summary, known source/Base block, Last Run Report, seven-step fallback, three dry-run outcomes, no-rule warning, Mother search, no-repeat exhaustion, traversal filtering, and mobile live-state ordering.
